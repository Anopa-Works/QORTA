document.addEventListener('DOMContentLoaded', () => {

    // --- Hamburger Menu Logic ---
    const hamburgerBtn = document.getElementById('hamburger-btn');
    const closeMenuBtn = document.getElementById('close-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');
    const mobileLinks = document.querySelectorAll('.mobile-nav-links a');

    if (hamburgerBtn && closeMenuBtn && mobileMenu) {
        hamburgerBtn.addEventListener('click', () => {
            mobileMenu.classList.add('active');
        });

        closeMenuBtn.addEventListener('click', () => {
            mobileMenu.classList.remove('active');
        });

        // Close menu when a link is clicked
        mobileLinks.forEach(link => {
            link.addEventListener('click', () => {
                mobileMenu.classList.remove('active');
            });
        });
    }

    // --- Services Pre-Selection Logic ---
    const serviceButtons = document.querySelectorAll('.service-card a');
    const timelineSelect = document.getElementById('b-service');

    serviceButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const serviceType = btn.getAttribute('data-service');
            if (timelineSelect) {
                if (serviceType === 'same-day') {
                    timelineSelect.value = 'Same-Day';
                } else if (serviceType === 'next-day') {
                    timelineSelect.value = 'Next-Day';
                } else {
                    timelineSelect.value = 'Economy';
                }
            }
        });
    });

    // --- Tracking Page Logic ---
    // Dummy data for tracking
    const demoOrders = {
        'H0123456789': {
            origin: '123 Main St, Anytown',
            originDate: '2023-10-26',
            destination: '456 Oak Ave, Otherville',
            destinationDate: '2023-10-27',
            status: 'Out for delivery',
            weight: '5 kg',
            customer: 'John Doe'
        },
        'H9876543210': {
            origin: '789 Pine Ln, Somewhere',
            originDate: '2023-10-25',
            destination: '101 Elm Rd, Nowhere',
            destinationDate: '2023-10-26',
            status: 'Delivered',
            weight: '10 kg',
            customer: 'Jane Smith'
        }
    };

    const fullTrackForm = document.getElementById('fullTrackForm');
    const fullTrackInput = document.getElementById('fullTrackInput');

    if (fullTrackForm) {
        fullTrackForm.addEventListener('submit', (e) => {
            e.preventDefault();
            let val = fullTrackInput.value.trim().toUpperCase();
            if (val === '') return;

            let order = demoOrders[val];
            if (!order) {
                // Mocking a newly generated order if they were just redirected
                if (val.startsWith('ERD-')) {
                    order = {
                        origin: 'Origin Address (Processing)',
                        originDate: 'Today',
                        destination: 'Destination Address (Processing)',
                        destinationDate: 'Tomorrow',
                        status: 'Booking Confirmed',
                        weight: 'Pending',
                        customer: 'Guest'
                    };
                } else {
                    order = demoOrders['H0123456789'];
                    val = 'H0123456789';
                }
            }

            // Update UI
            document.getElementById('td-tracking-id').textContent = val;
            document.getElementById('td-from').textContent = `${order.originDate} ${order.origin}`;
            document.getElementById('td-destination').textContent = `${order.destinationDate} ${order.destination}`;
            document.getElementById('td-customer').textContent = order.customer;
            document.getElementById('td-weight').textContent = order.weight;

            const statusNode = document.getElementById('td-status');
            statusNode.textContent = order.status;

            if (order.status === 'Delivered') {
                statusNode.style.color = '#10B981';
            } else if (order.status === 'Out for delivery') {
                statusNode.style.color = '#F5A623';
            } else {
                statusNode.style.color = 'var(--primary-red)';
            }
        });

        // Check if there is a tracking parameter in the URL (from booking simulation)
        const urlParams = new URLSearchParams(window.location.search);
        const trackParam = urlParams.get('track');
        if (trackParam) {
            fullTrackInput.value = trackParam;
            fullTrackForm.dispatchEvent(new Event('submit'));
        }
    }

    // --- Booking Form Simulation Logic ---
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const originInput = document.getElementById('b-origin').value;
            const destInput = document.getElementById('b-dest').value;
            const serviceLevel = document.getElementById('b-service').value || 'Standard';

            const submitBtn = document.getElementById('b-submit');
            const originalText = submitBtn.textContent;

            // Simulating API Call
            submitBtn.textContent = 'Processing...';
            submitBtn.disabled = true;

            setTimeout(() => {
                // Generate a fake new order
                const newId = 'ERD-' + Math.floor(10000 + Math.random() * 90000);
                alert(`Booking Confirmed! Your driver is on the way. Tracking ID: ${newId}`);

                // Redirect user to tracking page
                window.location.href = `tracking.html?track=${newId}`;

            }, 1500);

        });
    }

});
